package clases;

/**
 * Clase utilizada como padre de estudiante y profesor
 * 
 * @author entornos
 * @version 2.0
 * @since 1.0
 */
public class persona {
	// Metodos de clase. Edad y nombre
	int i_Edad;
	String s_Nombre;
}
